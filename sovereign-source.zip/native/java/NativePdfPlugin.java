package com.kaiserinconsulting.sovereignserve;

import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.core.content.FileProvider;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.File;
import java.io.FileOutputStream;
import java.util.concurrent.atomic.AtomicBoolean;

@CapacitorPlugin(name = "NativePdf")
public class NativePdfPlugin extends Plugin {
    private static final int PAGE_WIDTH = 1275;
    private static final int PAGE_HEIGHT = 1650;
    private static final int MAX_PAGES = 200;

    @PluginMethod
    public void createPdf(PluginCall call) {
        String html = call.getString("html");
        String fileName = sanitizeFileName(call.getString("fileName", "Sovereign-Serve.pdf"));
        if (html == null || html.trim().isEmpty()) {
            call.reject("HTML is required.");
            return;
        }
        getActivity().runOnUiThread(() -> renderPdf(call, html, fileName));
    }

    private void renderPdf(PluginCall call, String html, String fileName) {
        File directory = new File(getContext().getFilesDir(), "documents");
        if (!directory.exists() && !directory.mkdirs()) {
            call.reject("The private document directory could not be created.");
            return;
        }

        File output = new File(directory, fileName);
        WebView webView = new WebView(getActivity());
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setLoadWithOverviewMode(false);
        settings.setUseWideViewPort(false);
        webView.setBackgroundColor(Color.WHITE);
        webView.setLayerType(View.LAYER_TYPE_SOFTWARE, null);

        AtomicBoolean started = new AtomicBoolean(false);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                if (!started.compareAndSet(false, true)) return;
                view.postDelayed(() -> writePdf(call, view, output), 300L);
            }
        });

        webView.loadDataWithBaseURL(
            "https://appassets.androidplatform.net/",
            html,
            "text/html",
            "UTF-8",
            null
        );
    }

    private void writePdf(PluginCall call, WebView view, File output) {
        PdfDocument document = new PdfDocument();
        try {
            int widthSpec = View.MeasureSpec.makeMeasureSpec(PAGE_WIDTH, View.MeasureSpec.EXACTLY);
            int heightSpec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
            view.measure(widthSpec, heightSpec);

            int measuredHeight = Math.max(view.getMeasuredHeight(), PAGE_HEIGHT);
            int webContentHeight = (int) Math.ceil(view.getContentHeight() * view.getScale());
            int totalHeight = Math.max(measuredHeight, webContentHeight);
            int pageCount = Math.max(1, (int) Math.ceil(totalHeight / (double) PAGE_HEIGHT));
            if (pageCount > MAX_PAGES) {
                throw new IllegalStateException("The document is too long to render safely.");
            }

            view.layout(0, 0, PAGE_WIDTH, totalHeight);

            for (int pageIndex = 0; pageIndex < pageCount; pageIndex++) {
                PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(
                    PAGE_WIDTH,
                    PAGE_HEIGHT,
                    pageIndex + 1
                ).create();
                PdfDocument.Page page = document.startPage(pageInfo);
                Canvas canvas = page.getCanvas();
                canvas.drawColor(Color.WHITE);
                canvas.save();
                canvas.translate(0, -(pageIndex * PAGE_HEIGHT));
                view.draw(canvas);
                canvas.restore();
                document.finishPage(page);
            }

            if (output.exists() && !output.delete()) {
                throw new IllegalStateException("The prior PDF could not be replaced.");
            }
            try (FileOutputStream stream = new FileOutputStream(output)) {
                document.writeTo(stream);
                stream.flush();
            }

            JSObject result = new JSObject();
            result.put("path", output.getAbsolutePath());
            result.put("bytes", output.length());
            result.put("pages", pageCount);
            call.resolve(result);
        } catch (Exception error) {
            call.reject("The PDF file could not be created.", error);
        } finally {
            document.close();
            view.destroy();
        }
    }

    @PluginMethod
    public void sharePdf(PluginCall call) {
        String path = call.getString("path");
        if (path == null || path.trim().isEmpty()) {
            call.reject("A PDF path is required.");
            return;
        }

        File file = new File(path);
        if (!file.exists() || !file.isFile()) {
            call.reject("The PDF file was not found.");
            return;
        }

        try {
            Uri uri = FileProvider.getUriForFile(
                getContext(),
                getContext().getPackageName() + ".fileprovider",
                file
            );
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("application/pdf");
            intent.putExtra(Intent.EXTRA_STREAM, uri);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            getActivity().startActivity(
                Intent.createChooser(intent, call.getString("title", "Share Sovereign Serve PDF"))
            );
            call.resolve();
        } catch (Exception error) {
            call.reject("The PDF could not be shared.", error);
        }
    }

    private String sanitizeFileName(String value) {
        String clean = value == null
            ? "Sovereign-Serve.pdf"
            : value.replaceAll("[^A-Za-z0-9._-]", "-");
        return clean.toLowerCase().endsWith(".pdf") ? clean : clean + ".pdf";
    }
}
