package com.kaiserinconsulting.sovereignserve;

import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.provider.Settings;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.util.List;

@CapacitorPlugin(name = "TrustedLocation")
public class TrustedLocationPlugin extends Plugin {
    @PluginMethod
    public void getRiskSnapshot(PluginCall call) {
        try {
            LocationManager manager = (LocationManager) getContext().getSystemService(android.content.Context.LOCATION_SERVICE);
            Location best = null;
            List<String> providers = manager.getProviders(true);
            for (String provider : providers) {
                Location candidate;
                try { candidate = manager.getLastKnownLocation(provider); }
                catch (SecurityException error) { continue; }
                if (candidate == null) continue;
                if (best == null || candidate.getTime() > best.getTime() || candidate.getAccuracy() < best.getAccuracy()) best = candidate;
            }
            boolean mock = false;
            if (best != null) {
                mock = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ? best.isMock() : best.isFromMockProvider();
            }
            boolean developerMode = Settings.Global.getInt(getContext().getContentResolver(), Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) != 0;
            JSObject result = new JSObject();
            result.put("isMock", mock);
            result.put("developerMode", developerMode);
            result.put("provider", best == null ? "" : best.getProvider());
            result.put("providerTimestamp", best == null ? 0 : best.getTime());
            result.put("accuracy", best == null ? null : best.getAccuracy());
            call.resolve(result);
        } catch (Exception error) {
            call.reject("Location risk signals could not be evaluated.", error);
        }
    }
}
