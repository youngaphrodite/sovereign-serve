package com.kaiserinconsulting.sovereignserve;

import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.security.KeyStore;
import java.security.MessageDigest;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

@CapacitorPlugin(name = "EvidenceStore")
public class EvidenceStorePlugin extends Plugin {
    private static final String KEY_ALIAS = "sovereign_evidence_storage_v1";

    @PluginMethod
    public void saveEvidence(PluginCall call) {
        try {
            String storageId = safe(call.getString("storageId"));
            String caseId = safe(call.getString("caseId"));
            String attemptId = safe(call.getString("attemptId"));
            String originalBase64 = call.getString("originalBase64");
            String watermarkedBase64 = call.getString("watermarkedBase64");
            if (storageId.isEmpty() || originalBase64 == null || watermarkedBase64 == null) {
                call.reject("Evidence identifiers and both image payloads are required.");
                return;
            }
            byte[] original = Base64.decode(originalBase64, Base64.DEFAULT);
            byte[] watermarked = Base64.decode(watermarkedBase64, Base64.DEFAULT);
            File directory = new File(getContext().getFilesDir(), "evidence/" + caseId + "/" + attemptId + "/" + storageId);
            if (!directory.exists() && !directory.mkdirs()) throw new IllegalStateException("Evidence directory could not be created.");
            writeEncrypted(new File(directory, "original.enc"), original);
            writeEncrypted(new File(directory, "watermarked.enc"), watermarked);
            JSObject response = new JSObject();
            response.put("path", directory.getAbsolutePath());
            response.put("originalSha256", sha256(original));
            response.put("watermarkedSha256", sha256(watermarked));
            response.put("originalBytes", original.length);
            response.put("watermarkedBytes", watermarked.length);
            call.resolve(response);
        } catch (Exception error) {
            call.reject("Evidence could not be written to encrypted app-private storage.", error);
        }
    }

    @PluginMethod
    public void readEvidence(PluginCall call) {
        try {
            String storageId = safe(call.getString("storageId"));
            File directory = findEvidenceDirectory(storageId);
            if (directory == null) {
                call.reject("Evidence was not found.");
                return;
            }
            JSObject response = new JSObject();
            byte[] watermarked = readEncrypted(new File(directory, "watermarked.enc"));
            response.put("watermarkedBase64", Base64.encodeToString(watermarked, Base64.NO_WRAP));
            if (Boolean.TRUE.equals(call.getBoolean("includeOriginal", false))) {
                byte[] original = readEncrypted(new File(directory, "original.enc"));
                response.put("originalBase64", Base64.encodeToString(original, Base64.NO_WRAP));
            }
            call.resolve(response);
        } catch (Exception error) {
            call.reject("Evidence could not be read.", error);
        }
    }

    @PluginMethod
    public void deleteEvidence(PluginCall call) {
        String storageId = safe(call.getString("storageId"));
        File directory = findEvidenceDirectory(storageId);
        if (directory != null) deleteRecursively(directory);
        call.resolve();
    }

    @PluginMethod
    public void eraseAll(PluginCall call) {
        deleteRecursively(new File(getContext().getFilesDir(), "evidence"));
        call.resolve();
    }

    @PluginMethod
    public void getStorageStats(PluginCall call) {
        File directory = new File(getContext().getFilesDir(), "evidence");
        JSObject result = new JSObject();
        result.put("evidenceBytes", directorySize(directory));
        result.put("freeBytes", getContext().getFilesDir().getFreeSpace());
        call.resolve(result);
    }

    private File findEvidenceDirectory(String storageId) {
        return findRecursively(new File(getContext().getFilesDir(), "evidence"), storageId);
    }

    private File findRecursively(File root, String name) {
        if (root == null || !root.exists()) return null;
        if (root.isDirectory() && root.getName().equals(name)) return root;
        File[] children = root.listFiles();
        if (children == null) return null;
        for (File child : children) {
            if (child.isDirectory()) {
                File found = findRecursively(child, name);
                if (found != null) return found;
            }
        }
        return null;
    }

    private void writeEncrypted(File file, byte[] plaintext) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateStorageKey());
        byte[] ciphertext = cipher.doFinal(plaintext);
        try (DataOutputStream output = new DataOutputStream(new FileOutputStream(file))) {
            output.writeInt(cipher.getIV().length);
            output.write(cipher.getIV());
            output.write(ciphertext);
        }
    }

    private byte[] readEncrypted(File file) throws Exception {
        byte[] all;
        try (FileInputStream input = new FileInputStream(file); ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            byte[] chunk = new byte[8192];
            int read;
            while ((read = input.read(chunk)) != -1) buffer.write(chunk, 0, read);
            all = buffer.toByteArray();
        }
        try (DataInputStream input = new DataInputStream(new ByteArrayInputStream(all))) {
            int ivLength = input.readInt();
            if (ivLength < 12 || ivLength > 32) throw new IllegalStateException("Invalid evidence IV.");
            byte[] iv = new byte[ivLength];
            input.readFully(iv);
            byte[] ciphertext = new byte[all.length - 4 - ivLength];
            input.readFully(ciphertext);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateStorageKey(), new GCMParameterSpec(128, iv));
            return cipher.doFinal(ciphertext);
        }
    }

    private SecretKey getOrCreateStorageKey() throws Exception {
        KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
        keyStore.load(null);
        if (keyStore.containsAlias(KEY_ALIAS)) {
            return ((KeyStore.SecretKeyEntry) keyStore.getEntry(KEY_ALIAS, null)).getSecretKey();
        }
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build());
        return generator.generateKey();
    }

    private String sha256(byte[] bytes) throws Exception {
        byte[] digest = MessageDigest.getInstance("SHA-256").digest(bytes);
        StringBuilder builder = new StringBuilder();
        for (byte value : digest) builder.append(String.format("%02x", value));
        return builder.toString();
    }

    private String safe(String value) {
        return value == null ? "" : value.replaceAll("[^A-Za-z0-9._-]", "_");
    }

    private void deleteRecursively(File file) {
        if (file == null || !file.exists()) return;
        File[] children = file.listFiles();
        if (children != null) for (File child : children) deleteRecursively(child);
        //noinspection ResultOfMethodCallIgnored
        file.delete();
    }

    private long directorySize(File file) {
        if (file == null || !file.exists()) return 0;
        if (file.isFile()) return file.length();
        long size = 0;
        File[] children = file.listFiles();
        if (children != null) for (File child : children) size += directorySize(child);
        return size;
    }
}
