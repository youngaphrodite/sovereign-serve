package com.kaiserinconsulting.sovereignserve;

import android.os.Build;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyPermanentlyInvalidatedException;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.concurrent.Executor;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

@CapacitorPlugin(name = "SecureVault")
public class SecureVaultPlugin extends Plugin {
    private static final String KEY_ALIAS = "sovereign_serve_biometric_v1";
    private static final String PREFS = "sovereign_secure_vault";
    private static final String PREF_CIPHER = "wrapped_secret";
    private static final String PREF_IV = "wrapped_iv";

    @PluginMethod
    public void isBiometricAvailable(PluginCall call) {
        int status = BiometricManager.from(getContext()).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG);
        JSObject result = new JSObject();
        result.put("available", status == BiometricManager.BIOMETRIC_SUCCESS);
        result.put("enabled", getContext().getSharedPreferences(PREFS, 0).contains(PREF_CIPHER));
        result.put("status", status);
        call.resolve(result);
    }

    @PluginMethod
    public void enableBiometric(PluginCall call) {
        String secret = call.getString("secret");
        if (secret == null || secret.isEmpty()) {
            call.reject("A credential is required.");
            return;
        }
        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateBiometricKey());
            showPrompt(call, cipher, call.getString("reason", "Enable Biometric Unlock"), true, secret);
        } catch (Exception error) {
            call.reject("Biometric setup could not be initialized.", error);
        }
    }

    @PluginMethod
    public void unlockWithBiometric(PluginCall call) {
        try {
            String encrypted = getContext().getSharedPreferences(PREFS, 0).getString(PREF_CIPHER, null);
            String iv = getContext().getSharedPreferences(PREFS, 0).getString(PREF_IV, null);
            if (encrypted == null || iv == null) {
                call.reject("Biometric unlock has not been enabled.");
                return;
            }
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateBiometricKey(), new GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP)));
            showPrompt(call, cipher, call.getString("reason", "Unlock Sovereign Serve"), false, null);
        } catch (KeyPermanentlyInvalidatedException error) {
            clearBiometricState();
            call.reject("The biometric key was invalidated. Use the device PIN and enable biometrics again.", error);
        } catch (Exception error) {
            call.reject("Biometric unlock could not be initialized.", error);
        }
    }

    private void showPrompt(PluginCall call, Cipher cipher, String reason, boolean encrypting, String secret) {
        Executor executor = ContextCompat.getMainExecutor(getContext());
        BiometricPrompt prompt = new BiometricPrompt(getActivity(), executor, new BiometricPrompt.AuthenticationCallback() {
            @Override
            public void onAuthenticationError(int errorCode, @NonNull CharSequence errString) {
                super.onAuthenticationError(errorCode, errString);
                call.reject(errString.toString());
            }

            @Override
            public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
                super.onAuthenticationSucceeded(result);
                try {
                    Cipher authenticatedCipher = result.getCryptoObject() != null ? result.getCryptoObject().getCipher() : null;
                    if (authenticatedCipher == null) throw new IllegalStateException("No authenticated cipher was returned.");
                    if (encrypting) {
                        byte[] ciphertext = authenticatedCipher.doFinal(secret.getBytes(StandardCharsets.UTF_8));
                        getContext().getSharedPreferences(PREFS, 0).edit()
                            .putString(PREF_CIPHER, Base64.encodeToString(ciphertext, Base64.NO_WRAP))
                            .putString(PREF_IV, Base64.encodeToString(authenticatedCipher.getIV(), Base64.NO_WRAP))
                            .apply();
                        JSObject response = new JSObject();
                        response.put("enabled", true);
                        call.resolve(response);
                    } else {
                        String encrypted = getContext().getSharedPreferences(PREFS, 0).getString(PREF_CIPHER, null);
                        byte[] plaintext = authenticatedCipher.doFinal(Base64.decode(encrypted, Base64.NO_WRAP));
                        JSObject response = new JSObject();
                        response.put("secret", new String(plaintext, StandardCharsets.UTF_8));
                        call.resolve(response);
                    }
                } catch (Exception error) {
                    call.reject("The protected credential could not be processed.", error);
                }
            }
        });

        BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
            .setTitle("Sovereign Serve")
            .setSubtitle(reason)
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
            .setNegativeButtonText("Use Device PIN")
            .build();
        prompt.authenticate(info, new BiometricPrompt.CryptoObject(cipher));
    }

    @PluginMethod
    public void disableBiometric(PluginCall call) {
        clearBiometricState();
        call.resolve();
    }

    @PluginMethod
    public void setSecureScreen(PluginCall call) {
        boolean enabled = Boolean.TRUE.equals(call.getBoolean("enabled", true));
        getActivity().runOnUiThread(() -> {
            if (enabled) {
                getActivity().getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
            } else {
                getActivity().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
            }
            JSObject result = new JSObject();
            result.put("enabled", enabled);
            call.resolve(result);
        });
    }

    private SecretKey getOrCreateBiometricKey() throws Exception {
        KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
        keyStore.load(null);
        if (keyStore.containsAlias(KEY_ALIAS)) {
            return ((KeyStore.SecretKeyEntry) keyStore.getEntry(KEY_ALIAS, null)).getSecretKey();
        }
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        KeyGenParameterSpec.Builder builder = new KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setUserAuthenticationRequired(true)
            .setInvalidatedByBiometricEnrollment(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            builder.setUserAuthenticationParameters(0, KeyProperties.AUTH_BIOMETRIC_STRONG);
        } else {
            builder.setUserAuthenticationValidityDurationSeconds(-1);
        }
        generator.init(builder.build());
        return generator.generateKey();
    }

    private void clearBiometricState() {
        getContext().getSharedPreferences(PREFS, 0).edit().clear().apply();
        try {
            KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
            keyStore.load(null);
            if (keyStore.containsAlias(KEY_ALIAS)) keyStore.deleteEntry(KEY_ALIAS);
        } catch (Exception ignored) {}
    }
}
