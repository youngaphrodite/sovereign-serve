from __future__ import annotations

from pathlib import Path
from shutil import copy2
from PIL import Image
import re

ROOT = Path(__file__).resolve().parents[1]
ANDROID = ROOT / "android"
APP = ANDROID / "app"
PACKAGE_PATH = APP / "src/main/java/com/kaiserinconsulting/sovereignserve"
RES = APP / "src/main/res"

if not ANDROID.exists():
    raise SystemExit("Android platform does not exist. Run: npx cap add android")

PACKAGE_PATH.mkdir(parents=True, exist_ok=True)
for source in (ROOT / "native/java").glob("*.java"):
    copy2(source, PACKAGE_PATH / source.name)

copy2(ROOT / "native/AndroidManifest.xml", APP / "src/main/AndroidManifest.xml")
copy2(ROOT / "native/proguard-rules.pro", APP / "proguard-rules.pro")
xml_dest = RES / "xml"
xml_dest.mkdir(parents=True, exist_ok=True)
for source in (ROOT / "native/res/xml").glob("*.xml"):
    copy2(source, xml_dest / source.name)

build_file = APP / "build.gradle"
build = build_file.read_text(encoding="utf-8")
build = re.sub(r'versionCode\s+\d+', 'versionCode 103', build)
build = re.sub(r'versionName\s+"[^"]+"', 'versionName "1.0.3"', build)

# Add release hardening without duplicating the block.
release_pattern = r'release\s*\{[^}]*\}'
release_replacement = '''release {
            minifyEnabled true
            shrinkResources true
            debuggable false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }'''
build = re.sub(release_pattern, release_replacement, build, count=1, flags=re.S)

# Native plugins use AndroidX Biometric and modern WebKit APIs.
needle = "dependencies {"
extra = '''dependencies {
    implementation "androidx.biometric:biometric:1.1.0"
    implementation "androidx.webkit:webkit:1.16.0"'''
if 'androidx.biometric:biometric' not in build:
    build = build.replace(needle, extra, 1)
build_file.write_text(build, encoding="utf-8")

# Ensure branded colors and splash theme.
values = RES / "values"
values.mkdir(parents=True, exist_ok=True)
(values / "colors.xml").write_text('''<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="colorPrimary">#081A33</color>
    <color name="colorPrimaryDark">#061225</color>
    <color name="colorAccent">#C9A227</color>
    <color name="splash_background">#081A33</color>
</resources>
''', encoding="utf-8")

# Overwrite Capacitor's dedicated adaptive-icon background resource instead
# of defining the same color in two files.
(values / "ic_launcher_background.xml").write_text('''<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="ic_launcher_background">#081A33</color>
</resources>
''', encoding="utf-8")

styles = values / "styles.xml"
styles.write_text('''<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="AppTheme" parent="Theme.AppCompat.Light.DarkActionBar">
        <item name="colorPrimary">@color/colorPrimary</item>
        <item name="colorPrimaryDark">@color/colorPrimaryDark</item>
        <item name="colorAccent">@color/colorAccent</item>
    </style>
    <style name="AppTheme.NoActionBar" parent="Theme.AppCompat.DayNight.NoActionBar">
        <item name="windowActionBar">false</item>
        <item name="windowNoTitle">true</item>
        <item name="android:background">@null</item>
    </style>
    <style name="AppTheme.NoActionBarLaunch" parent="Theme.SplashScreen">
        <item name="windowSplashScreenBackground">@color/splash_background</item>
        <item name="windowSplashScreenAnimatedIcon">@mipmap/ic_launcher_foreground</item>
        <item name="postSplashScreenTheme">@style/AppTheme.NoActionBar</item>
        <item name="android:windowBackground">@drawable/splash</item>
    </style>
</resources>
''', encoding="utf-8")

# Build branded launcher and splash assets from the approved emblem.
emblem = Image.open(ROOT / "www/brand-emblem.png").convert("RGBA")
navy = (8, 26, 51, 255)

def contain(source: Image.Image, size: int, occupancy: float, background=None) -> Image.Image:
    canvas = Image.new("RGBA", (size, size), background if background is not None else (0, 0, 0, 0))
    target = int(size * occupancy)
    item = source.copy()
    item.thumbnail((target, target), Image.Resampling.LANCZOS)
    canvas.alpha_composite(item, ((size - item.width) // 2, (size - item.height) // 2))
    return canvas

# Adaptive foreground density assets (108dp canvas with safe-zone padding).
densities = {
    "mdpi": 108,
    "hdpi": 162,
    "xhdpi": 216,
    "xxhdpi": 324,
    "xxxhdpi": 432,
}
for density, px in densities.items():
    folder = RES / f"mipmap-{density}"
    folder.mkdir(parents=True, exist_ok=True)
    foreground = contain(emblem, px, 0.66)
    foreground.save(folder / "ic_launcher_foreground.png", optimize=True)
    legacy = contain(emblem, px, 0.72, navy)
    legacy.save(folder / "ic_launcher.png", optimize=True)
    legacy.save(folder / "ic_launcher_round.png", optimize=True)

anydpi = RES / "mipmap-anydpi-v26"
anydpi.mkdir(parents=True, exist_ok=True)
adaptive = '''<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_background"/>
    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>
</adaptive-icon>
'''
(anydpi / "ic_launcher.xml").write_text(adaptive, encoding="utf-8")
(anydpi / "ic_launcher_round.xml").write_text(adaptive, encoding="utf-8")

# Pre-Android-12 fallback splash.
drawable = RES / "drawable"
drawable.mkdir(parents=True, exist_ok=True)
splash = contain(emblem, 1200, 0.42, navy)
splash.save(drawable / "splash.png", optimize=True)

print("Prepared Sovereign Serve Android 1.0.3 native project.")
