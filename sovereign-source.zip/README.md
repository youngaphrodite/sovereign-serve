# Sovereign Serve

Sovereign Serve is a local-first Android process-serving evidence and case-management application for Kaiserin Consulting LLC.

## Automated Test Build

Every commit to `main` runs the GitHub Actions workflow **Build Sovereign Serve Android**. When successful, its artifact contains `app-debug.apk`, which can be installed on an Android phone for private testing.

Package: `com.kaiserinconsulting.sovereignserve`  
Version: `1.0.3` (`103`)

The debug APK is for testing. Google Play submission requires a separately signed release Android App Bundle and final policy/legal review.

## Build Corrections In 1.0.3

- Uses a public-registry pnpm cloud build.
- Removes duplicate adaptive launcher color resources.
- Replaces inaccessible Android print callbacks with a compile-safe app-private PDF renderer.
